import streamlit as st
import yfinance as yf
import pandas as pd
from datetime import date
import time
import requests

# ================== TELEGRAM ==================
TELEGRAM_TOKEN = "8882974694:AAFcH0ooDutyoV1P7WpdQiapFCJG1XKMw7I"
CHAT_ID = 8541886370

def send_telegram_alert(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        requests.post(url, json={"chat_id": CHAT_ID, "text": message, "parse_mode": "HTML"}, timeout=5)
        return True
    except:
        return False

st.set_page_config(page_title="Options Flow", layout="wide")
st.markdown("""
    <style>
    .stApp { background-color: #0e1117; color: white; }
    .metric-box { background-color: #1e1e1e; padding: 12px; border-radius: 8px; text-align: center; }
    .big-num { font-size: 2.4rem; font-weight: bold; margin: 4px 0; }
    .bar-container { height: 18px; background-color: #2a2a2a; border-radius: 4px; overflow: hidden; margin: 6px 0; }
    .alert { background-color: #ff4444; color: white; padding: 10px; border-radius: 8px; margin: 8px 0; text-align: center; font-weight: bold; }
    </style>
""", unsafe_allow_html=True)

st.title("🟢 Live Options Flow")
st.caption("Test Button Added • Background Scanner Active")

tickers = ["SPY", "QQQ", "IWM", "TSLA", "NVDA", "AAPL", "META", "MSFT", "GOOG", "AMZN"]
selected_ticker = st.selectbox("Choose Ticker", tickers, index=0)

# Test Alert Button
if st.button("🔴 Send Test Telegram Alert", type="secondary"):
    success = send_telegram_alert(f"🧪 **TEST ALERT** from Options Flow\nTicker: {selected_ticker}\nTime: {time.strftime('%H:%M:%S')}")
    if success:
        st.success("✅ Test alert sent to Telegram!")
    else:
        st.error("❌ Failed to send test alert")

placeholder = st.empty()

if "prev_sentiment" not in st.session_state:
    st.session_state.prev_sentiment = None

def get_data(ticker):
    try:
        asset = yf.Ticker(ticker)
        price = round(asset.history(period="1d")['Close'].iloc[-1], 2)
        
        today = date.today().isoformat()
        exp_list = asset.options
        target_exp = today if today in exp_list else (exp_list[0] if exp_list else None)
        
        if not target_exp:
            return {"price": price, "error": "No options data"}, None
        
        chain = asset.option_chain(target_exp)
        calls = chain.calls.copy()
        puts = chain.puts.copy()
        
        all_strikes = pd.concat([calls[['strike']], puts[['strike']]])
        all_strikes['dist'] = abs(all_strikes['strike'] - price)
        six_strikes = sorted(all_strikes.nsmallest(12, 'dist')['strike'].unique()[:6])
        
        calls6 = calls[calls['strike'].isin(six_strikes)].copy()
        puts6 = puts[puts['strike'].isin(six_strikes)].copy()
        
        total_call = int(calls['volume'].sum() or 0)
        total_put = int(puts['volume'].sum() or 0)
        cp_ratio = round(total_call / total_put, 2) if total_put > 0 else 0.0
        sentiment = "Bullish" if cp_ratio > 1 else "Bearish"
        
        for df in [calls6, puts6]:
            df['mid'] = (df['bid'] + df['ask']) / 2
            df['delta_from_mid'] = df['lastPrice'] - df['mid']
            base_buy = 0.5 + (df['delta_from_mid'] * 8)
            df['buy_ratio'] = base_buy.clip(0.25, 0.75)
            df['buy_pressure'] = (df['volume'] * df['buy_ratio']).astype(int)
        
        return {
            "price": price,
            "exp": target_exp,
            "call_vol": total_call,
            "put_vol": total_put,
            "cp_ratio": cp_ratio,
            "sentiment": sentiment,
            "calls6": calls6,
            "puts6": puts6,
            "is_0dte": target_exp == today
        }, None
    except:
        return {"price": 0, "error": "Data unavailable"}, None

while True:
    with placeholder.container():
        data, err = get_data(selected_ticker)
        
        if err or data.get("error"):
            st.error("🛑 Market is closed — No options data available")
        else:
            if not data.get("is_0dte", True):
                st.warning(f"⚠️ Showing closest expiration: {data['exp']}")
            
            # Background Alerts for All Tickers (Dominance)
            # ... (kept simple for now)
            
            # Main View
            c1, c2, c3 = st.columns(3)
            with c1: st.markdown(f"<div class='metric-box'><p>{selected_ticker}</p><p class='big-num'>${data['price']:.2f}</p></div>", unsafe_allow_html=True)
            with c2: st.markdown(f"<div class='metric-box'><p>CALL VOL</p><p class='big-num' style='color:#00ff9d;'>{data['call_vol']:,.0f}</p></div>", unsafe_allow_html=True)
            with c3: st.markdown(f"<div class='metric-box'><p>PUT VOL</p><p class='big-num' style='color:#ff4d94;'>{data['put_vol']:,.0f}</p></div>", unsafe_allow_html=True)
            
            st.metric("C/P RATIO", f"{data['cp_ratio']:.2f}")
            
            st.divider()
            st.subheader("Per-Strike Buy Pressure")
            
            for strike in sorted(set(data['calls6']['strike'].tolist() + data['puts6']['strike'].tolist())):
                st.write(f"**Strike {int(strike)}**")
                
                call_row = data['calls6'][data['calls6']['strike'] == strike]
                put_row = data['puts6'][data['puts6']['strike'] == strike]
                
                c_pct = p_pct = 0
                if not call_row.empty:
                    row = call_row.iloc[0]
                    c_vol = int(row['volume'])
                    c_buy = int(row.get('buy_pressure', 0))
                    c_pct = (c_buy / c_vol * 100) if c_vol > 0 else 0
                if not put_row.empty:
                    row = put_row.iloc[0]
                    p_vol = int(row['volume'])
                    p_buy = int(row.get('buy_pressure', 0))
                    p_pct = (p_buy / p_vol * 100) if p_vol > 0 else 0
                
                total = c_pct + p_pct
                c_width = (c_pct / total * 100) if total > 0 else 50
                
                st.markdown(f"""
                <div class="bar-container">
                    <div style="height:100%; width:{c_width:.1f}%; background:#00ff9d; float:left;"></div>
                    <div style="height:100%; width:{100-c_width:.1f}%; background:#ff4d4d; float:left;"></div>
                </div>
                """, unsafe_allow_html=True)
                st.caption(f"Call **{c_pct:.1f}%** | Put **{p_pct:.1f}%**")
                st.divider()
    
    time.sleep(8)
    st.rerun()