@echo off
title SPY Options Flow Launcher

cd "%USERPROFILE%\OneDrive\Desktop"
echo Starting Options Flow App...
streamlit run spy_0dte_dashboard.py