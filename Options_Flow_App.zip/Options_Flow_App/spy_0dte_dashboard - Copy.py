import streamlit as st
import yfinance as yf
import pandas as pd
from datetime import date
import time
import requests

# ================== TELEGRAM ==================
TELEGRAM_TOKEN = "8882974694:AAFcH0ooDutyoV1P7WpdQiapFCJG1XKMw7I"
CHAT_ID = 8541886370

def send_telegram_alert(message):
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
        requests.post(url, json={"chat_id": CHAT_ID, "text": message}, timeout=5)
    except:
        pass

st.set_page_config(page_title="Options Flow", layout="wide")
st.markdown("<style>.stApp { background-color: #0e1117; color: white; }</style>", unsafe_allow_html=True)

st.title("🟢 Live Options Flow")
tickers = ["SPY", "QQQ", "TSLA", "NVDA", "GOOG", "AMZN"]
selected_ticker = st.selectbox("Choose Ticker", tickers, index=0)

placeholder = st.empty()

if "prev_sentiment" not in st.session_state:
    st.session_state.prev_sentiment = None

def get_data(ticker):
    try:
        asset = yf.Ticker(ticker)
        price = round(asset.history(period="1d")['Close'].iloc[-1], 2)
        
        today = date.today().isoformat()
        exp_list = asset.options
        
        # Try 0DTE first
        target_exp = today if today in exp_list else None
        
        if not target_exp and exp_list:
            target_exp = exp_list[0]  # fallback to nearest
        
        if not target_exp:
            return {"price": price, "error": "No options chain available"}, None
        
        chain = asset.option_chain(target_exp)
        calls = chain.calls.copy()
        puts = chain.puts.copy()
        
        # 6 closest strikes
        all_strikes = pd.concat([calls[['strike']], puts[['strike']]])
        all_strikes['dist'] = abs(all_strikes['strike'] - price)
        six_strikes = sorted(all_strikes.nsmallest(12, 'dist')['strike'].unique()[:6])
        
        calls6 = calls[calls['strike'].isin(six_strikes)].sort_values('strike').copy()
        puts6 = puts[puts['strike'].isin(six_strikes)].sort_values('strike').copy()
        
        total_call = int(calls['volume'].sum() or 0)
        total_put = int(puts['volume'].sum() or 0)
        cp_ratio = round(total_call / total_put, 2) if total_put > 0 else 0.0
        sentiment = "Bullish" if cp_ratio > 1 else "Bearish"
        
        for df in [calls6, puts6]:
            df['mid'] = (df['bid'] + df['ask']) / 2
            df['delta_from_mid'] = df['lastPrice'] - df['mid']
            df['moneyness'] = (df['strike'] - price) / price
            base_buy = 0.5 + (df['delta_from_mid'] * 8) - (df['moneyness'] * 0.3)
            df['buy_ratio'] = base_buy.clip(0.25, 0.75)
            df['buy_pressure'] = (df['volume'] * df['buy_ratio']).astype(int)
            df['sell_pressure'] = df['volume'] - df['buy_pressure']
        
        return {
            "price": price,
            "exp": target_exp,
            "call_vol": total_call,
            "put_vol": total_put,
            "cp_ratio": cp_ratio,
            "sentiment": sentiment,
            "calls6": calls6,
            "puts6": puts6,
            "is_0dte": target_exp == today
        }, None
    except:
        return {"price": price, "error": "Data unavailable"}, None

while True:
    with placeholder.container():
        data, err = get_data(selected_ticker)
        
        if err or data.get("error"):
            st.error("🛑 0DTE expired — Market is closed")
            st.metric(f"{selected_ticker} Price", f"${data.get('price', 0):.2f}")
        else:
            if not data.get("is_0dte", True):
                st.warning(f"Showing nearest expiration: {data['exp']} (0DTE not available)")
            
            # Your alerts (Sentiment Flip + Extreme Pressure) stay here
            # ... (keep the alert logic you like)

            # Main dashboard metrics + strike bars go here

    time.sleep(8)
    st.rerun()