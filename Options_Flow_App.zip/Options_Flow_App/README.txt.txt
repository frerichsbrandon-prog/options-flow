🚀 Options Flow Dashboard
========================

A live 0DTE options flow viewer with Telegram alerts.

### How to Run (Super Simple)

1. **Double-click** the file `Start_Options_Flow.bat` on your Desktop.
2. The app should automatically open in your browser.

**First time only:**
Open Command Prompt and run this command:
```cmd
pip install streamlit pandas yfinance requests